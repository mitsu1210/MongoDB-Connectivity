## This is a markdown file

AMAZON FINE FOOD REVIEWS APPLICATION


1. INTRODUCTION

The purpose of this application is to enable its users to search for food reviews by inserting the keywords in the search bar and performing the search operation. It also allows them to add a comment to the reviews they see. This application uses the MongoDB, No-SQL database to store the reviews information. Therefore, all the actions performed by the user on this application will be saved to the MongoDB database at the back-end. The front-end for this application has been developed using HTML, CSS and the back-end has been developed using Java Servlets.


2. INSTALLATION REQUIREMENTS

Apache Tomcat 8 Server for Ubuntu 16.04

Go to the following link and follow the installation instructions.

https://www.digitalocean.com/community/tutorials/how-to-install-apache-tomcat-8-on-ubuntu-16-04

              
3. INSTRUCTIONS TO RUN THE FILE

Create a directory structure under Tomcat folder for the downloaded application.

1.  Go to your tomcat folder. Under the webapps folder, create a new folder named �WebApplications�. 
2.  Create the src and WEB-INF directories under WebApplications folder, and create a directory named �MyClasses� under WEB-INF. Add all the .java files in the src folder of the downloaded application under this folder. Place the index.html file directly under the WebApplications folder.
3.  Change the directory to your working directory by typing the following command in Ubuntu terminal.
javac -d ../WEB-INF/classes/ MyServlet.java
4. Call the html file from the web browser by typing the following.
http://localhost:8080/WebApplications/index.html


